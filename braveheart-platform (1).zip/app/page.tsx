"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, Shield, Users, Calendar, ArrowRight, CheckCircle } from "lucide-react"
import RiskChecker from "@/components/risk-checker"
import StoriesWall from "@/components/stories-wall"
import DetectionTools from "@/components/detection-tools"

export default function HomePage() {
  const [activeSection, setActiveSection] = useState("home")

  const stats = [
    { label: "Women Detected Early", value: "12,847", icon: Shield },
    { label: "Stories Shared", value: "3,291", icon: Heart },
    { label: "Support Pledged", value: "$847K", icon: Users },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-purple-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-pink-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-pink-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                BraveHeart
              </span>
            </div>
            <div className="hidden md:flex space-x-8">
              <button
                onClick={() => setActiveSection("home")}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeSection === "home" ? "text-pink-600 bg-pink-50" : "text-gray-700 hover:text-pink-600"
                }`}
              >
                Home
              </button>
              <button
                onClick={() => setActiveSection("checker")}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeSection === "checker" ? "text-pink-600 bg-pink-50" : "text-gray-700 hover:text-pink-600"
                }`}
              >
                Risk Checker
              </button>
              <button
                onClick={() => setActiveSection("stories")}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeSection === "stories" ? "text-pink-600 bg-pink-50" : "text-gray-700 hover:text-pink-600"
                }`}
              >
                Stories
              </button>
              <button
                onClick={() => setActiveSection("tools")}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeSection === "tools" ? "text-pink-600 bg-pink-50" : "text-gray-700 hover:text-pink-600"
                }`}
              >
                Detection Tools
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      {activeSection === "home" && (
        <>
          <section className="relative py-20 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
              <div className="text-center mb-16">
                <Badge className="mb-4 bg-pink-100 text-pink-800 hover:bg-pink-200">
                  🔍 Early Detection Saves Lives
                </Badge>
                <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                  We Don't Just Tell Stories—
                  <span className="bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                    We Detect Hope
                  </span>
                </h1>
                <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                  BraveHeart empowers you with AI-powered early detection tools, connects you with a community of
                  fighters, and provides personalized support throughout your journey.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    size="lg"
                    className="bg-pink-600 hover:bg-pink-700 text-white px-8 py-3"
                    onClick={() => setActiveSection("checker")}
                  >
                    <Shield className="mr-2 h-5 w-5" />
                    Check Yourself Now
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-pink-300 text-pink-600 hover:bg-pink-50 px-8 py-3"
                    onClick={() => setActiveSection("stories")}
                  >
                    <Heart className="mr-2 h-5 w-5" />
                    Hear Her Story
                  </Button>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
                {stats.map((stat, index) => (
                  <Card key={index} className="text-center border-pink-100 hover:shadow-lg transition-shadow">
                    <CardContent className="pt-6">
                      <stat.icon className="h-12 w-12 text-pink-600 mx-auto mb-4" />
                      <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                      <div className="text-gray-600">{stat.label}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Quick Features */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <Card
                  className="border-pink-100 hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => setActiveSection("checker")}
                >
                  <CardHeader>
                    <CardTitle className="flex items-center text-pink-600">
                      <Shield className="mr-2 h-5 w-5" />
                      AI Risk Assessment
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Get personalized risk insights through our ML-powered questionnaire in under 5 minutes.
                    </p>
                    <div className="flex items-center text-pink-600 text-sm font-medium">
                      Start Assessment <ArrowRight className="ml-1 h-4 w-4" />
                    </div>
                  </CardContent>
                </Card>

                <Card
                  className="border-pink-100 hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => setActiveSection("stories")}
                >
                  <CardHeader>
                    <CardTitle className="flex items-center text-pink-600">
                      <Heart className="mr-2 h-5 w-5" />
                      Fighters' Stories
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Read inspiring journeys from survivors and fighters who've walked this path before you.
                    </p>
                    <div className="flex items-center text-pink-600 text-sm font-medium">
                      Read Stories <ArrowRight className="ml-1 h-4 w-4" />
                    </div>
                  </CardContent>
                </Card>

                <Card
                  className="border-pink-100 hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => setActiveSection("tools")}
                >
                  <CardHeader>
                    <CardTitle className="flex items-center text-pink-600">
                      <Calendar className="mr-2 h-5 w-5" />
                      Detection Tools
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Access self-exam guides, reminders, and educational resources for proactive health.
                    </p>
                    <div className="flex items-center text-pink-600 text-sm font-medium">
                      Explore Tools <ArrowRight className="ml-1 h-4 w-4" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </section>
        </>
      )}

      {/* Risk Checker Section */}
      {activeSection === "checker" && <RiskChecker />}

      {/* Stories Wall Section */}
      {activeSection === "stories" && <StoriesWall />}

      {/* Detection Tools Section */}
      {activeSection === "tools" && <DetectionTools />}

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Heart className="h-8 w-8 text-pink-400" />
              <span className="text-2xl font-bold">BraveHeart</span>
            </div>
            <p className="text-gray-400 mb-4">
              Empowering early detection, celebrating courage, supporting every journey.
            </p>
            <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
              <CheckCircle className="h-4 w-4 text-green-400" />
              <span>GDPR Compliant • End-to-End Encrypted • Medically Reviewed</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
