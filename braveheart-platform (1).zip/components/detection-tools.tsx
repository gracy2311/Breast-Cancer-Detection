"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, Play, Clock, BookOpen, Bell, Smartphone, Brain } from "lucide-react"
import AIImageAnalysis from "@/components/ai-image-analysis"

interface Tool {
  id: string
  title: string
  description: string
  type: "guide" | "reminder" | "video" | "download"
  icon: any
  duration?: string
  downloadUrl?: string
}

const tools: Tool[] = [
  {
    id: "1",
    title: "Monthly Self-Exam Guide",
    description:
      "Step-by-step visual guide for performing breast self-examinations. Learn the proper technique and what to look for.",
    type: "guide",
    icon: BookOpen,
    duration: "5 min read",
  },
  {
    id: "2",
    title: "Self-Exam Video Tutorial",
    description:
      "Interactive video demonstration showing proper self-examination techniques with medical expert guidance.",
    type: "video",
    icon: Play,
    duration: "8 min video",
  },
  {
    id: "3",
    title: "Monthly Reminder Setup",
    description:
      "Set up personalized reminders for monthly self-exams and annual screenings directly to your calendar.",
    type: "reminder",
    icon: Bell,
    duration: "2 min setup",
  },
  {
    id: "4",
    title: "Early Warning Signs PDF",
    description:
      "Comprehensive downloadable guide covering all early warning signs and when to consult a healthcare provider.",
    type: "download",
    icon: Download,
    downloadUrl: "/guides/early-warning-signs.pdf",
  },
  {
    id: "5",
    title: "Nutrition & Prevention Guide",
    description:
      "Evidence-based dietary recommendations and lifestyle changes that may help reduce breast cancer risk.",
    type: "download",
    icon: Download,
    downloadUrl: "/guides/nutrition-prevention.pdf",
  },
  {
    id: "6",
    title: "Mobile App Integration",
    description: "Connect with health tracking apps to monitor changes and set up automated health reminders.",
    type: "reminder",
    icon: Smartphone,
    duration: "3 min setup",
  },
  {
    id: "7",
    title: "AI Image Analysis",
    description:
      "Upload histopathological images for AI-powered classification using our ResNet-152 deep learning model.",
    type: "guide",
    icon: Brain,
    duration: "Instant analysis",
  },
]

export default function DetectionTools() {
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null)
  const [reminderSet, setReminderSet] = useState(false)
  const [showAIAnalysis, setShowAIAnalysis] = useState(false)

  const handleToolClick = (tool: Tool) => {
    if (tool.id === "7") {
      setShowAIAnalysis(true)
      return
    }
    if (tool.type === "download" && tool.downloadUrl) {
      // Simulate download
      console.log(`Downloading: ${tool.downloadUrl}`)
      return
    }
    if (tool.type === "reminder") {
      setReminderSet(true)
      setTimeout(() => setReminderSet(false), 3000)
      return
    }
    setSelectedTool(tool)
  }

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-pink-100 text-pink-800">🛠️ Proactive Health Tools</Badge>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Detection Tools & Resources</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Empower yourself with educational resources, self-examination guides, and proactive health monitoring tools.
          </p>
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {tools.map((tool) => (
            <Card
              key={tool.id}
              className="border-pink-100 hover:shadow-lg transition-all cursor-pointer transform hover:-translate-y-1"
              onClick={() => handleToolClick(tool)}
            >
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <tool.icon className="h-8 w-8 text-pink-600" />
                  <Badge
                    variant="outline"
                    className={`text-xs ${
                      tool.type === "guide"
                        ? "border-blue-300 text-blue-600"
                        : tool.type === "video"
                          ? "border-purple-300 text-purple-600"
                          : tool.type === "reminder"
                            ? "border-green-300 text-green-600"
                            : "border-orange-300 text-orange-600"
                    }`}
                  >
                    {tool.type}
                  </Badge>
                </div>
                <CardTitle className="text-lg">{tool.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">{tool.description}</p>
                <div className="flex items-center justify-between">
                  {tool.duration && (
                    <span className="text-sm text-gray-500 flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {tool.duration}
                    </span>
                  )}
                  <Button size="sm" className="bg-pink-600 hover:bg-pink-700 text-white">
                    {tool.type === "download"
                      ? "Download"
                      : tool.type === "reminder"
                        ? "Set Reminder"
                        : tool.type === "video"
                          ? "Watch"
                          : "Read Guide"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Self-Exam Guide Section */}
        <Card className="bg-gradient-to-r from-pink-50 to-purple-50 border-pink-200 mb-12">
          <CardContent className="py-12">
            <div className="text-center mb-8">
              <BookOpen className="h-16 w-16 text-pink-600 mx-auto mb-4" />
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Monthly Self-Examination Guide</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Regular self-examinations are crucial for early detection. Follow these steps monthly, ideally 3-5 days
                after your menstrual period ends.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 border-2 border-pink-200">
                  <span className="text-2xl font-bold text-pink-600">1</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Visual Inspection</h3>
                <p className="text-gray-600 text-sm">
                  Stand in front of a mirror with arms at your sides. Look for changes in size, shape, or skin texture.
                </p>
              </div>
              <div className="text-center">
                <div className="bg-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 border-2 border-pink-200">
                  <span className="text-2xl font-bold text-pink-600">2</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Physical Examination</h3>
                <p className="text-gray-600 text-sm">
                  Use your fingertips to feel for lumps or changes. Check both breasts and the area under your arms.
                </p>
              </div>
              <div className="text-center">
                <div className="bg-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 border-2 border-pink-200">
                  <span className="text-2xl font-bold text-pink-600">3</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Document Changes</h3>
                <p className="text-gray-600 text-sm">
                  Note any changes and consult your healthcare provider if you notice anything unusual.
                </p>
              </div>
            </div>

            <div className="text-center mt-8">
              <Button className="bg-pink-600 hover:bg-pink-700 text-white px-8 py-3">Watch Detailed Video Guide</Button>
            </div>
          </CardContent>
        </Card>

        {/* Reminder Success Message */}
        {reminderSet && (
          <div className="fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-2 z-50">
            <Bell className="h-5 w-5" />
            <span>Monthly reminder set successfully!</span>
          </div>
        )}

        {/* Tool Modal */}
        {selectedTool && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <Card className="max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex items-center space-x-4">
                    <selectedTool.icon className="h-8 w-8 text-pink-600" />
                    <div>
                      <CardTitle className="text-2xl">{selectedTool.title}</CardTitle>
                      <p className="text-gray-600">{selectedTool.description}</p>
                    </div>
                  </div>
                  <Button
                    onClick={() => setSelectedTool(null)}
                    variant="ghost"
                    size="sm"
                    className="text-gray-500 hover:text-gray-700"
                  >
                    ✕
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {selectedTool.type === "video" ? (
                  <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center mb-6">
                    <div className="text-center">
                      <Play className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">Video content would be embedded here</p>
                      <Button className="mt-4 bg-pink-600 hover:bg-pink-700 text-white">Play Video Tutorial</Button>
                    </div>
                  </div>
                ) : (
                  <div className="prose max-w-none">
                    <p className="text-gray-700 mb-6">
                      This is where the detailed content for {selectedTool.title} would be displayed. The content would
                      include step-by-step instructions, images, and interactive elements to help users understand and
                      implement the guidance.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* AI Image Analysis Section */}
        {showAIAnalysis && (
          <div className="mt-16">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-bold text-gray-900">AI-Powered Image Analysis</h2>
              <Button onClick={() => setShowAIAnalysis(false)} variant="outline" className="border-gray-300">
                Back to Tools
              </Button>
            </div>
            <AIImageAnalysis />
          </div>
        )}
      </div>
    </section>
  )
}
