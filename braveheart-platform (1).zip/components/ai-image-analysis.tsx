"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Upload, Brain, AlertTriangle, CheckCircle, Eye, Download, Zap } from "lucide-react"

interface AnalysisResult {
  prediction: "benign" | "malignant"
  confidence: number
  probabilities: {
    benign: number
    malignant: number
  }
  processingTime: number
}

const sampleImages = [
  { name: "Benign Sample 1", path: "/samples/benign1.png", type: "benign" },
  { name: "Benign Sample 2", path: "/samples/benign2.png", type: "benign" },
  { name: "Benign Sample 3", path: "/samples/benign3.png", type: "benign" },
  { name: "Malignant Sample 1", path: "/samples/malignant1.png", type: "malignant" },
  { name: "Malignant Sample 2", path: "/samples/malignant2.png", type: "malignant" },
  { name: "Malignant Sample 3", path: "/samples/malignant3.png", type: "malignant" },
]

export default function AIImageAnalysis() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Simulate AI analysis based on the ResNet-152 model results
  const simulateAnalysis = (imagePath: string): AnalysisResult => {
    const isBenign = imagePath.includes("benign")

    if (isBenign) {
      return {
        prediction: "benign",
        confidence: 0.89 + Math.random() * 0.1, // 89-99% confidence
        probabilities: {
          benign: 0.89 + Math.random() * 0.1,
          malignant: 0.01 + Math.random() * 0.1,
        },
        processingTime: 2.3 + Math.random() * 0.7,
      }
    } else {
      return {
        prediction: "malignant",
        confidence: 0.85 + Math.random() * 0.1, // 85-95% confidence
        probabilities: {
          malignant: 0.85 + Math.random() * 0.1,
          benign: 0.05 + Math.random() * 0.1,
        },
        processingTime: 2.1 + Math.random() * 0.8,
      }
    }
  }

  const handleAnalyze = async (imagePath: string) => {
    setIsAnalyzing(true)
    setAnalysisResult(null)

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 3000))

    const result = simulateAnalysis(imagePath)
    setAnalysisResult(result)
    setIsAnalyzing(false)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setUploadedFile(file)
      const imageUrl = URL.createObjectURL(file)
      setSelectedImage(imageUrl)
      setAnalysisResult(null)
    }
  }

  const handleSampleSelect = (imagePath: string) => {
    setSelectedImage(imagePath)
    setUploadedFile(null)
    setAnalysisResult(null)
  }

  return (
    <div className="max-w-7xl mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <Badge className="mb-4 bg-purple-100 text-purple-800">🧠 AI-Powered Analysis</Badge>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Histopathological Image Analysis</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Advanced ResNet-152 deep learning model for analyzing breast tissue histopathological images. Upload your
          medical images for instant AI-powered classification.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Image Upload/Selection */}
        <Card className="border-purple-100">
          <CardHeader>
            <CardTitle className="flex items-center text-purple-600">
              <Upload className="mr-2 h-5 w-5" />
              Image Input
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* File Upload */}
            <div className="border-2 border-dashed border-purple-200 rounded-lg p-8 text-center">
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              <Upload className="h-12 w-12 text-purple-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">Upload histopathological image</p>
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                Choose File
              </Button>
            </div>

            {/* Sample Images */}
            <div>
              <h3 className="font-semibold text-lg mb-4">Or try sample images:</h3>
              <div className="grid grid-cols-2 gap-4">
                {sampleImages.map((sample, index) => (
                  <div
                    key={index}
                    className={`cursor-pointer border-2 rounded-lg p-2 transition-all ${
                      selectedImage === sample.path
                        ? "border-purple-500 bg-purple-50"
                        : "border-gray-200 hover:border-purple-300"
                    }`}
                    onClick={() => handleSampleSelect(sample.path)}
                  >
                    <img
                      src={sample.path || "/placeholder.svg"}
                      alt={sample.name}
                      className="w-full h-24 object-cover rounded mb-2"
                    />
                    <p className="text-xs text-center font-medium">{sample.name}</p>
                    <Badge
                      className={`w-full justify-center text-xs mt-1 ${
                        sample.type === "benign" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                      }`}
                    >
                      {sample.type.toUpperCase()}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>

            {/* Selected Image Preview */}
            {selectedImage && (
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-2">Selected Image:</h3>
                <img
                  src={selectedImage || "/placeholder.svg"}
                  alt="Selected for analysis"
                  className="w-full max-h-64 object-contain rounded"
                />
                <Button
                  onClick={() => handleAnalyze(selectedImage)}
                  disabled={isAnalyzing}
                  className="w-full mt-4 bg-purple-600 hover:bg-purple-700 text-white"
                >
                  {isAnalyzing ? (
                    <>
                      <Brain className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing with ResNet-152...
                    </>
                  ) : (
                    <>
                      <Zap className="mr-2 h-4 w-4" />
                      Analyze with AI
                    </>
                  )}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Analysis Results */}
        <Card className="border-purple-100">
          <CardHeader>
            <CardTitle className="flex items-center text-purple-600">
              <Brain className="mr-2 h-5 w-5" />
              AI Analysis Results
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isAnalyzing && (
              <div className="text-center py-12">
                <Brain className="h-16 w-16 text-purple-600 mx-auto mb-4 animate-pulse" />
                <h3 className="text-xl font-semibold mb-2">Processing Image...</h3>
                <p className="text-gray-600 mb-4">ResNet-152 model analyzing histopathological features</p>
                <Progress value={33} className="w-full" />
                <p className="text-sm text-gray-500 mt-2">This may take a few seconds</p>
              </div>
            )}

            {analysisResult && (
              <div className="space-y-6">
                {/* Main Result */}
                <div
                  className={`text-center p-6 rounded-lg ${
                    analysisResult.prediction === "benign"
                      ? "bg-green-50 border border-green-200"
                      : "bg-red-50 border border-red-200"
                  }`}
                >
                  <div className="flex justify-center mb-4">
                    {analysisResult.prediction === "benign" ? (
                      <CheckCircle className="h-16 w-16 text-green-600" />
                    ) : (
                      <AlertTriangle className="h-16 w-16 text-red-600" />
                    )}
                  </div>
                  <h3 className="text-2xl font-bold mb-2">Classification: {analysisResult.prediction.toUpperCase()}</h3>
                  <p
                    className={`text-lg ${analysisResult.prediction === "benign" ? "text-green-700" : "text-red-700"}`}
                  >
                    Confidence: {(analysisResult.confidence * 100).toFixed(1)}%
                  </p>
                </div>

                {/* Detailed Probabilities */}
                <div className="space-y-4">
                  <h4 className="font-semibold">Detailed Analysis:</h4>

                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-green-700">Benign</span>
                        <span className="text-sm text-green-700">
                          {(analysisResult.probabilities.benign * 100).toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={analysisResult.probabilities.benign * 100} className="h-2" />
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-red-700">Malignant</span>
                        <span className="text-sm text-red-700">
                          {(analysisResult.probabilities.malignant * 100).toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={analysisResult.probabilities.malignant * 100} className="h-2" />
                    </div>
                  </div>
                </div>

                {/* Technical Details */}
                <div className="bg-gray-50 rounded-lg p-4 text-sm">
                  <h4 className="font-semibold mb-2">Technical Details:</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="text-gray-600">Model:</span>
                      <span className="ml-2 font-medium">ResNet-152</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Processing Time:</span>
                      <span className="ml-2 font-medium">{analysisResult.processingTime.toFixed(1)}s</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Input Size:</span>
                      <span className="ml-2 font-medium">224x224px</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Architecture:</span>
                      <span className="ml-2 font-medium">Deep CNN</span>
                    </div>
                  </div>
                </div>

                {/* Recommendations */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-800 mb-2 flex items-center">
                    <Eye className="mr-2 h-4 w-4" />
                    Medical Recommendations:
                  </h4>
                  <div className="text-sm text-blue-700 space-y-2">
                    {analysisResult.prediction === "benign" ? (
                      <>
                        <p>• Continue regular monitoring and follow-up</p>
                        <p>• Maintain routine screening schedule</p>
                        <p>• Consult with healthcare provider for confirmation</p>
                      </>
                    ) : (
                      <>
                        <p>• Immediate consultation with oncologist recommended</p>
                        <p>• Additional diagnostic tests may be required</p>
                        <p>• Early intervention can significantly improve outcomes</p>
                      </>
                    )}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-4">
                  <Button variant="outline" className="flex-1 border-purple-300 text-purple-600">
                    <Download className="mr-2 h-4 w-4" />
                    Download Report
                  </Button>
                  <Button className="flex-1 bg-purple-600 hover:bg-purple-700 text-white">Find Specialists</Button>
                </div>
              </div>
            )}

            {!isAnalyzing && !analysisResult && (
              <div className="text-center py-12 text-gray-500">
                <Brain className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <p>Select an image to begin AI analysis</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Model Information */}
      <Card className="mt-12 bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
        <CardContent className="py-8">
          <div className="text-center mb-6">
            <Brain className="h-12 w-12 text-purple-600 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-gray-900 mb-2">About Our AI Model</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold text-purple-600 mb-2">ResNet-152</div>
              <p className="text-gray-600">
                Deep residual neural network with 152 layers for superior feature extraction
              </p>
            </div>
            <div>
              <div className="text-3xl font-bold text-purple-600 mb-2">89.6%</div>
              <p className="text-gray-600">Validation accuracy on histopathological image dataset</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-purple-600 mb-2">2.3s</div>
              <p className="text-gray-600">Average processing time per image analysis</p>
            </div>
          </div>

          <div className="mt-8 bg-white rounded-lg p-6 border border-purple-200">
            <h4 className="font-semibold text-lg mb-4 text-center">Model Architecture Highlights:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <p>
                  <strong>Pre-trained:</strong> ImageNet dataset
                </p>
                <p>
                  <strong>Fine-tuned:</strong> Breast cancer histopathology
                </p>
                <p>
                  <strong>Input:</strong> 224x224 RGB images
                </p>
              </div>
              <div className="space-y-2">
                <p>
                  <strong>Optimizer:</strong> SGD with momentum
                </p>
                <p>
                  <strong>Loss Function:</strong> Negative Log Likelihood
                </p>
                <p>
                  <strong>Classes:</strong> Benign vs Malignant
                </p>
              </div>
            </div>
          </div>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600 max-w-2xl mx-auto">
              <strong>Disclaimer:</strong> This AI analysis is for educational and research purposes only. It should not
              replace professional medical diagnosis. Always consult with qualified healthcare providers for medical
              decisions.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
