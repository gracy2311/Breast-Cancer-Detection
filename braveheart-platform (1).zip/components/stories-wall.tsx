"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, Calendar, MapPin, Flame, MessageCircle } from "lucide-react"

interface Story {
  id: string
  name: string
  age: number
  location: string
  stage: string
  diagnosis_date: string
  story: string
  image: string
  candles: number
  messages: number
  tags: string[]
}

const stories: Story[] = [
  {
    id: "1",
    name: "Sarah M.",
    age: 34,
    location: "California, USA",
    stage: "Survivor - 3 years",
    diagnosis_date: "March 2021",
    story:
      "I found a small lump during my monthly self-exam. Thanks to early detection, I caught it at Stage 1. Today, I'm cancer-free and helping other women learn the importance of self-examination. Early detection saved my life.",
    image: "/placeholder.svg?height=300&width=300",
    candles: 1247,
    messages: 89,
    tags: ["Early Detection", "Stage 1", "Self-Exam"],
  },
  {
    id: "2",
    name: "Maria L.",
    age: 42,
    location: "Texas, USA",
    stage: "Fighter - In Treatment",
    diagnosis_date: "January 2024",
    story:
      "Currently going through chemotherapy, but I'm staying strong with the support of my family and this amazing community. Every day is a gift, and I'm fighting with everything I have.",
    image: "/placeholder.svg?height=300&width=300",
    candles: 892,
    messages: 156,
    tags: ["Chemotherapy", "Stage 2", "Community Support"],
  },
  {
    id: "3",
    name: "Jennifer K.",
    age: 28,
    location: "New York, USA",
    stage: "Survivor - 5 years",
    diagnosis_date: "August 2019",
    story:
      "Diagnosed at 23, I was terrified. But with early intervention and an incredible medical team, I not only survived but thrived. Now I advocate for young women to be aware and proactive about their health.",
    image: "/placeholder.svg?height=300&width=300",
    candles: 2156,
    messages: 234,
    tags: ["Young Survivor", "Advocacy", "Prevention"],
  },
]

export default function StoriesWall() {
  const [selectedStory, setSelectedStory] = useState<Story | null>(null)
  const [filter, setFilter] = useState<string>("all")

  const filteredStories =
    filter === "all" ? stories : stories.filter((story) => story.stage.toLowerCase().includes(filter))

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-pink-100 text-pink-800">💪 Real Stories, Real Strength</Badge>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Fighters' Wall of Courage</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Every story shared here represents courage, hope, and the power of early detection. These brave women
            inspire us all to stay vigilant and support each other.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex justify-center space-x-4 mb-12">
          <Button
            onClick={() => setFilter("all")}
            variant={filter === "all" ? "default" : "outline"}
            className={
              filter === "all" ? "bg-pink-600 hover:bg-pink-700" : "border-pink-300 text-pink-600 hover:bg-pink-50"
            }
          >
            All Stories
          </Button>
          <Button
            onClick={() => setFilter("survivor")}
            variant={filter === "survivor" ? "default" : "outline"}
            className={
              filter === "survivor" ? "bg-pink-600 hover:bg-pink-700" : "border-pink-300 text-pink-600 hover:bg-pink-50"
            }
          >
            Survivors
          </Button>
          <Button
            onClick={() => setFilter("fighter")}
            variant={filter === "fighter" ? "default" : "outline"}
            className={
              filter === "fighter" ? "bg-pink-600 hover:bg-pink-700" : "border-pink-300 text-pink-600 hover:bg-pink-50"
            }
          >
            Current Fighters
          </Button>
        </div>

        {/* Stories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredStories.map((story) => (
            <Card
              key={story.id}
              className="border-pink-100 hover:shadow-lg transition-all cursor-pointer transform hover:-translate-y-1"
              onClick={() => setSelectedStory(story)}
            >
              <CardHeader className="pb-4">
                <div className="flex items-center space-x-4">
                  <img
                    src={story.image || "/placeholder.svg"}
                    alt={`${story.name}'s photo`}
                    className="w-16 h-16 rounded-full object-cover border-2 border-pink-200"
                  />
                  <div>
                    <CardTitle className="text-lg">{story.name}</CardTitle>
                    <p className="text-sm text-gray-600 flex items-center">
                      <MapPin className="h-3 w-3 mr-1" />
                      {story.location}
                    </p>
                  </div>
                </div>
                <Badge
                  className={`w-fit ${
                    story.stage.includes("Survivor") ? "bg-green-100 text-green-800" : "bg-blue-100 text-blue-800"
                  }`}
                >
                  {story.stage}
                </Badge>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 mb-4 line-clamp-3">{story.story}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {story.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs border-pink-300 text-pink-600">
                      {tag}
                    </Badge>
                  ))}
                </div>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center">
                      <Flame className="h-4 w-4 mr-1 text-orange-500" />
                      {story.candles}
                    </span>
                    <span className="flex items-center">
                      <MessageCircle className="h-4 w-4 mr-1 text-blue-500" />
                      {story.messages}
                    </span>
                  </div>
                  <span className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    {story.diagnosis_date}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Story Modal */}
        {selectedStory && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <Card className="max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex items-center space-x-4">
                    <img
                      src={selectedStory.image || "/placeholder.svg"}
                      alt={`${selectedStory.name}'s photo`}
                      className="w-20 h-20 rounded-full object-cover border-2 border-pink-200"
                    />
                    <div>
                      <CardTitle className="text-2xl">{selectedStory.name}</CardTitle>
                      <p className="text-gray-600 flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {selectedStory.location} • Age {selectedStory.age}
                      </p>
                      <Badge
                        className={`mt-2 ${
                          selectedStory.stage.includes("Survivor")
                            ? "bg-green-100 text-green-800"
                            : "bg-blue-100 text-blue-800"
                        }`}
                      >
                        {selectedStory.stage}
                      </Badge>
                    </div>
                  </div>
                  <Button
                    onClick={() => setSelectedStory(null)}
                    variant="ghost"
                    size="sm"
                    className="text-gray-500 hover:text-gray-700"
                  >
                    ✕
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-semibold text-lg mb-2">Her Story</h3>
                  <p className="text-gray-700 leading-relaxed">{selectedStory.story}</p>
                </div>

                <div className="flex flex-wrap gap-2">
                  {selectedStory.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="border-pink-300 text-pink-600">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="flex items-center space-x-6">
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-orange-300 text-orange-600 hover:bg-orange-50"
                    >
                      <Flame className="h-4 w-4 mr-2" />
                      Light a Candle ({selectedStory.candles})
                    </Button>
                    <Button variant="outline" size="sm" className="border-blue-300 text-blue-600 hover:bg-blue-50">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Send Support ({selectedStory.messages})
                    </Button>
                  </div>
                  <span className="text-sm text-gray-500 flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    Diagnosed {selectedStory.diagnosis_date}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Call to Action */}
        <div className="text-center mt-16">
          <Card className="bg-gradient-to-r from-pink-50 to-purple-50 border-pink-200">
            <CardContent className="py-12">
              <Heart className="h-12 w-12 text-pink-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Share Your Story</h3>
              <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                Your journey can inspire and help others. Share your story of courage, early detection, or ongoing fight
                to give hope to women everywhere.
              </p>
              <Button className="bg-pink-600 hover:bg-pink-700 text-white px-8 py-3">Share Your Story</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
