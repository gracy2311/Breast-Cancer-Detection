"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, Shield, ArrowLeft, ArrowRight, CheckCircle } from "lucide-react"

interface Question {
  id: string
  question: string
  options: { value: number; label: string }[]
  category: "symptoms" | "family" | "lifestyle"
}

const questions: Question[] = [
  {
    id: "age",
    question: "What is your age group?",
    category: "lifestyle",
    options: [
      { value: 0, label: "Under 30" },
      { value: 1, label: "30-39" },
      { value: 2, label: "40-49" },
      { value: 3, label: "50-59" },
      { value: 4, label: "60+" },
    ],
  },
  {
    id: "family_history",
    question: "Do you have a family history of breast or ovarian cancer?",
    category: "family",
    options: [
      { value: 0, label: "No family history" },
      { value: 2, label: "Distant relative (aunt, cousin)" },
      { value: 4, label: "Close relative (mother, sister)" },
      { value: 5, label: "Multiple close relatives" },
    ],
  },
  {
    id: "lumps",
    question: "Have you noticed any lumps or changes in your breast?",
    category: "symptoms",
    options: [
      { value: 0, label: "No changes noticed" },
      { value: 3, label: "Small, moveable lump" },
      { value: 5, label: "Hard, fixed lump" },
      { value: 4, label: "Skin changes or dimpling" },
    ],
  },
  {
    id: "pain",
    question: "Do you experience persistent breast pain or tenderness?",
    category: "symptoms",
    options: [
      { value: 0, label: "No pain" },
      { value: 1, label: "Occasional discomfort" },
      { value: 2, label: "Regular pain during cycle" },
      { value: 3, label: "Persistent, unusual pain" },
    ],
  },
  {
    id: "lifestyle",
    question: "How would you describe your lifestyle?",
    category: "lifestyle",
    options: [
      { value: 0, label: "Very active, healthy diet" },
      { value: 1, label: "Moderately active" },
      { value: 2, label: "Sedentary lifestyle" },
      { value: 3, label: "High stress, poor diet" },
    ],
  },
]

export default function RiskChecker() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<string, number>>({})
  const [showResults, setShowResults] = useState(false)

  const handleAnswer = (questionId: string, value: number) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }))
  }

  const calculateRisk = () => {
    const totalScore = Object.values(answers).reduce((sum, score) => sum + score, 0)
    const maxScore = questions.reduce((sum, q) => sum + Math.max(...q.options.map((o) => o.value)), 0)
    return Math.round((totalScore / maxScore) * 100)
  }

  const getRiskLevel = (score: number) => {
    if (score < 20)
      return { level: "Low", color: "text-green-600", bgColor: "bg-green-50", borderColor: "border-green-200" }
    if (score < 40)
      return { level: "Moderate", color: "text-yellow-600", bgColor: "bg-yellow-50", borderColor: "border-yellow-200" }
    if (score < 60)
      return { level: "Elevated", color: "text-orange-600", bgColor: "bg-orange-50", borderColor: "border-orange-200" }
    return { level: "High", color: "text-red-600", bgColor: "bg-red-50", borderColor: "border-red-200" }
  }

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setShowResults(true)
    }
  }

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const progress = ((currentQuestion + 1) / questions.length) * 100

  if (showResults) {
    const riskScore = calculateRisk()
    const riskInfo = getRiskLevel(riskScore)

    return (
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <Card className={`${riskInfo.bgColor} ${riskInfo.borderColor} border-2`}>
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                {riskInfo.level === "Low" ? (
                  <Shield className="h-16 w-16 text-green-600" />
                ) : (
                  <AlertTriangle className={`h-16 w-16 ${riskInfo.color}`} />
                )}
              </div>
              <CardTitle className="text-3xl mb-2">Your Risk Assessment</CardTitle>
              <Badge className={`${riskInfo.color} text-lg px-4 py-2`}>{riskInfo.level} Risk Level</Badge>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className={`text-6xl font-bold ${riskInfo.color} mb-2`}>{riskScore}%</div>
                <p className="text-gray-600">Based on your responses, this is your estimated risk indicator</p>
              </div>

              <div className="bg-white rounded-lg p-6 border">
                <h3 className="text-xl font-semibold mb-4 flex items-center">
                  <CheckCircle className="mr-2 h-5 w-5 text-green-600" />
                  Recommended Next Steps
                </h3>
                <div className="space-y-3">
                  {riskScore < 30 ? (
                    <>
                      <p className="flex items-start">
                        <span className="text-green-600 mr-2">•</span>
                        Continue regular self-examinations monthly
                      </p>
                      <p className="flex items-start">
                        <span className="text-green-600 mr-2">•</span>
                        Maintain healthy lifestyle habits
                      </p>
                      <p className="flex items-start">
                        <span className="text-green-600 mr-2">•</span>
                        Schedule routine mammogram as per age guidelines
                      </p>
                    </>
                  ) : (
                    <>
                      <p className="flex items-start">
                        <span className="text-orange-600 mr-2">•</span>
                        Schedule a consultation with your healthcare provider
                      </p>
                      <p className="flex items-start">
                        <span className="text-orange-600 mr-2">•</span>
                        Consider more frequent screening if recommended
                      </p>
                      <p className="flex items-start">
                        <span className="text-orange-600 mr-2">•</span>
                        Discuss family history and genetic testing options
                      </p>
                    </>
                  )}
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Important:</strong> This assessment is for educational purposes only and should not replace
                  professional medical advice. Please consult with a healthcare provider for proper evaluation and
                  screening.
                </p>
              </div>

              <div className="flex gap-4 justify-center">
                <Button
                  onClick={() => {
                    setShowResults(false)
                    setCurrentQuestion(0)
                    setAnswers({})
                  }}
                  variant="outline"
                  className="border-pink-300 text-pink-600 hover:bg-pink-50"
                >
                  Take Assessment Again
                </Button>
                <Button className="bg-pink-600 hover:bg-pink-700 text-white">Find Healthcare Providers</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    )
  }

  const currentQ = questions[currentQuestion]
  const isAnswered = answers[currentQ.id] !== undefined

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <Badge className="mb-4 bg-pink-100 text-pink-800">AI-Powered Risk Assessment</Badge>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Early Detection Self-Checker</h1>
          <p className="text-xl text-gray-600">Answer a few questions to get personalized risk insights</p>
        </div>

        <Card className="border-pink-100">
          <CardHeader>
            <div className="flex justify-between items-center mb-4">
              <span className="text-sm text-gray-500">
                Question {currentQuestion + 1} of {questions.length}
              </span>
              <Badge variant="outline" className="text-pink-600 border-pink-300">
                {currentQ.category}
              </Badge>
            </div>
            <Progress value={progress} className="mb-4" />
            <CardTitle className="text-2xl">{currentQ.question}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {currentQ.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswer(currentQ.id, option.value)}
                className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                  answers[currentQ.id] === option.value
                    ? "border-pink-500 bg-pink-50 text-pink-700"
                    : "border-gray-200 hover:border-pink-300 hover:bg-pink-25"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{option.label}</span>
                  {answers[currentQ.id] === option.value && <CheckCircle className="h-5 w-5 text-pink-600" />}
                </div>
              </button>
            ))}

            <div className="flex justify-between pt-6">
              <Button
                onClick={prevQuestion}
                disabled={currentQuestion === 0}
                variant="outline"
                className="border-gray-300"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>
              <Button
                onClick={nextQuestion}
                disabled={!isAnswered}
                className="bg-pink-600 hover:bg-pink-700 text-white"
              >
                {currentQuestion === questions.length - 1 ? "Get Results" : "Next"}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
